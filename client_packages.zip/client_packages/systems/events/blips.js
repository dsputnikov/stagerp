let governemnt = mp.blips.new(419, new mp.Vector3(-536, -218, 38), {
    name: 'Правительство',
    color: 4,
    shortRange: true,
});

let news = mp.blips.new(498, new mp.Vector3(-1070, -246, 53), {
    name: 'Новостное агенство',
    color: 1,
    shortRange: true,
});

let tuning = mp.blips.new(72, new mp.Vector3(-351, -134, 29), {
    name: 'Тюнинг сервис',
    color: 4,
    shortRange: true,
});

let autosaloon_medium = mp.blips.new(225, new mp.Vector3(-75.39668273925781, 64.27561950683594, 57.21598434448242), {
    name: 'Автосалон среднего класса',
    color: 57,
    shortRange: true,
});

let airport = mp.blips.new(90, new mp.Vector3(-1032.6295166015625, -2732.058837890625, 63.038902282714844), {
    name: 'Аеропорт ',
    color: 0,
    shortRange: true,
});

let coliseum = mp.blips.new(24, new mp.Vector3(-319.33905029296875, -1974.3548583984375, 87.76261901855469), {
    name: 'Колизей ',
    color: 0,
    shortRange: true,
});
