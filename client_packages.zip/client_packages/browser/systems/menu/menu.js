
var Menu = new Vue({
    el: '#menu',
    data: {
        active: false,
        open: 0,
        name: '',
        gender: '',
        id: 19,
        lvl: 0,
        money: 100,
        bank: 9,
        property: [
            { type: 'vehicle', id: 0 },
            { type: 'house', id: 34 },
        ],
    },
    methods: {
    }
})
