
  import draggable from 'vuedraggable'

Vue.component('button-counter', {
    data: function () {
        return {
            count: 0
        }
    },
    template: ''
})