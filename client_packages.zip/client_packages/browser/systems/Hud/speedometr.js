
var Speedometer = new Vue({
    el: '#speedometer',
    data: {
        active: false,
        speed: 0,
    },
    methods: {

    }
})
