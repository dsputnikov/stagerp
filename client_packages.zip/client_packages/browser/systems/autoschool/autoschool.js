
var Autoschool = new Vue({
    el: '#autoschool',
    data: {
        active: false,
    }
})