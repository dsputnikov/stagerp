# Tooltip

### tooltip

<example :value="example1"></example>

### tooltipPlacement

<example :value="example2"></example>

### tooltipFormatter

<example :value="example3"></example>

::: example tooltip :::