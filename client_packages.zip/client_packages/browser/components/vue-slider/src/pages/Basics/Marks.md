# Marks

### When `marks` is `true`

<example :value="example1"></example>

### When the type of `marks` is `Object`

<example :value="example2"></example>

### When the type of `marks` is `Array`

<example :value="example3"></example>

### When the type of `marks` is `Function`

<example :value="example4"></example>

### Use with `included`

<example :value="example5"></example>

### Use `hideLabel` to hide the label

<example :value="example6"></example>

::: example marks :::