# Process

## process

### When the type of `process` is `Boolean`

<example :value="example1"></example>

### When the type of `process` is `Function`

<example :value="example2"></example>

::: example process :::