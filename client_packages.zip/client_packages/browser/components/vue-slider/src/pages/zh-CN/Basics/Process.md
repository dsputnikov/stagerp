# 进度条

## process

### 当值的类型为 `Boolean`

<example :value="example1"></example>

### 当值的类型为 `Function`

<example :value="example2"></example>

::: example process :::