# 范围模式

以下参数只在范围模式下有效

  - `enableCross`
  - `minRange`
  - `maxRange`
  - `fixed`

### 禁止滑块交叉穿越

<example :value="example1"></example>

### 限制滑块之间的距离

<example :value="example2"></example>

::: example range :::