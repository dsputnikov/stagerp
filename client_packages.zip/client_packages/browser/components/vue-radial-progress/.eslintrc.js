module.exports = {
  root: true,
  parserOptions: {
    sourceType: 'module'
  },

  extends: 'standard',
  // required to lint *.vue files
  plugins: [
    'html'
  ]
}
