module.exports = {
  key: 'myKey1'
};
